var respObj = response.content.asJSON;
response.content = '';
response.headers['Content-Type'] = 'application/json';
var body = response.content.asJSON;